debtsUL = document.getElementById('debts')
descriptionInput = document.getElementById('description')

showButton = document.getElementById('show-button')
hudeButton = document.getElementById('hide-button')
addButton = document.getElementById('add-button')

addContainer = document.getElementById('add-container')

// kada se klikne na dugme "+ Dodaj" prikaži "prozor"
showButton.addEventListener('click', () => addContainer.classList.add('show'))
// kada se klikne na dugme "x Zatvori" zatvori "prozor"
hudeButton.addEventListener('click', () => addContainer.classList.remove('show'))

// kada se klikne na dugme "Potvrdi"
addButton.addEventListener('click', () => {
    // dodajemo novo zaduženje u listu
    // Napomena
    // uneti tekst u okviru textarea elementa dohvatamo pomoću value promenljive
    addDebt(descriptionInput.value, false)
    // zatvaramo "prozor"
    addContainer.classList.remove('show')
})

// na početku, učitavamo sve prethodno sačuvana zaduženja
loadLocalStorage()

function loadLocalStorage() {
    // učitavamo sva naša zaduženja iz lokalnog skladišta
    // localStorage.getItem(naziv_item-a) dohvata željeni item ukoliko postoji
    debts = JSON.parse(localStorage.getItem('debts'))

    // ukoliko zaduženja ne postoje u skladištu (obrisali smo kolačiće ili prvi put koristimo stranicu)
    if (debts != undefined) {
        // svako od zaduženja iz skladišta ćemo prikazati na stranici
        debts.forEach(debt => addDebt(debt.text, debt.isReturned))

        // dogovor je da za svako zaduženje čuvamo (uvek možemo proširiti)
        // text - sam tekst, odnosno opis zaduženja i
        // isReturned - da li je zaduženje vraćeno (ispunjeno)
    }
}

// funkcija za dodavanje novog zaduženja ili zaduženja pročitanog iz lokalnog skladišta
function addDebt(description, isReturned) {

    // nad stranicom kreiramo li element
    debtEl = document.createElement('li')
    // u okviru novog li elementa postavljamo opis zaduženja
    debtEl.innerText = description

    if (isReturned) {
        // ukoliko je zaduženje vraćeno dodelićemo li elementu 'returned' klasu kako bi bio precrtanog izgleda
        debtEl.classList.add('returned')
    }

    // ukoliko se klikne levim klikom miša nad zaduženjem
    debtEl.addEventListener('click', (e) => {
        // e.target je element na koji je korisnik kliknuo
        clickedElement = e.target
        // toggle - ukoliko je elementu već pridružena klasa 'completed' uklonićemo je
        // u suprotnom ćemo je dodeliti
        clickedElement.classList.toggle('returned')

        // ažuriraćemo lokalno skladište (zbog izmenjenog statusa zaduženja)
        updateLocalStorage()
    })

    // ukoliko se klikne desnim klikom miša nad zaduženjem
    debtEl.addEventListener('contextmenu', (e) => {
        // ukoliko bismo izostavili e.preventDefault()
        // standardni niz opcija koji se pojavljuje pri desnom kliku bi se iscrtao
        e.preventDefault()

        // e.target je element na koji je korisnik kliknuo
        clickedElement = e.target
        // obrisaćemo li element
        clickedElement.remove()

        // ažuriraćemo lokalno skladište (zbog obrisanog zaduženja)
        updateLocalStorage()
    })

    // kreirani li element sa zaduženjem dodajemo u okviru niza zaduženja (li -> unordered list)
    debtsUL.appendChild(debtEl)
    // brišemo opis kako ne bi ostao za naredno dodavanje
    descriptionInput.value = ''

    // ažuriraćemo lokalno skladište (zbog dodatog zaduženja)
    updateLocalStorage()
}

// funkcija za čuvanje, odnosno аžuriranje, zaduženja u okviru lokalnog skladišta
function updateLocalStorage() {
    // dohvatamo sve li elemente
    debtsEl = document.querySelectorAll('li')
    debts = []

    // za svaki li element
    debtsEl.forEach(debtEl => {
        // napravićemo debt u okviru kojeg ćemo čuvati informacije o tom zaduženju
        debt = {
            text: debtEl.innerText, // čuvamo opis zaduženja
            isReturned: debtEl.classList.contains('returned') // čuvamo status zaduženja (da li je ispunjeno ili ne)
        }

        // debts informacije čuvamo u okviru niza drugih debt informacija, dodavanjem na kraj niza (push)
        debts.push(debt)
    })

    // jednom kada imamo sve debt informacije, sačuvaćemo ih u okviru lokalnog skladišta
    localStorage.setItem('debts', JSON.stringify(debts))
}
