debtsUL = document.getElementById('debts')
descriptionInput = document.getElementById('description')

showButton = document.getElementById('show-button')
hudeButton = document.getElementById('hide-button')
addButton = document.getElementById('add-button')

addContainer = document.getElementById('add-container')

// kada se klikne na dugme "+ Dodaj" prikaži "prozor"
showButton.addEventListener('click', () => addContainer.classList.add('show'))
// kada se klikne na dugme "x Zatvori" zatvori "prozor"
hudeButton.addEventListener('click', () => addContainer.classList.remove('show'))

// kada se klikne na dugme "Potvrdi"
addButton.addEventListener('click', () => {
    // dodajemo novo zaduženje u listu
    // Napomena
    // uneti tekst u okviru textarea elementa dohvatamo pomoću value promenljive
    addDebt(descriptionInput.value, false)
    // zatvaramo "prozor"
    addContainer.classList.remove('show')
})

// DOPUNITI
// funkcija za dodavanje novog zaduženja ili zaduženja pročitanog iz lokalnog skladišta
function addDebt(description, isReturned) {

}

// DOPUNITI
// implementirati neophodnu logiku za čuvanje zaduženja u okviru lokalnog skladišta (local storage)